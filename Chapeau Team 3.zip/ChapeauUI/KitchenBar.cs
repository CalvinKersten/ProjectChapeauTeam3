﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ChapeauModel;
using ChapeauDAL;
using ChapeauService;
using System.Windows.Forms.VisualStyles;
using System.Data.SqlClient;

namespace ChapeauUI
{
    public partial class KitchenBar : Form
    {
        public KitchenBar()
        {
            InitializeComponent();
            ShowOrderDetailPanel();
        }
        public List<OrderDetail> GetOrderDetails()
        {
            OrderDetailService orderDetailService = new OrderDetailService();
            List<OrderDetail> orderDetail = orderDetailService.GetOrderDetails();
            return orderDetail;
        }

        public List<OrderDetail> RunningOrders()
        {
            OrderDetailService orderDetailService = new OrderDetailService();
            List<OrderDetail> runningOrder = orderDetailService.RunningOrders();
            return runningOrder;
        }
        public List<OrderDetail> KitchenOrder()
        {
            OrderDetailService orderDetailService = new OrderDetailService();
            List<OrderDetail> kitchenOrder = orderDetailService.KitchenOrder();
            return kitchenOrder;
        }
        public List<OrderDetail> CompletedOrders()
        {
            OrderDetailService orderDetailService = new OrderDetailService();
            List<OrderDetail> completedOrder = orderDetailService.CompletedOrders();
            return completedOrder;
        }


        private void DisplayRunningOrders(List<OrderDetail> runningOrder)
        {
            ListViewRunningOrders.Clear();
            ListViewRunningOrders.View = View.Details;
            ListViewRunningOrders.Columns.Add("Order ID", 110);
            ListViewRunningOrders.Columns.Add("Order number", 155); //should be table number
            ListViewRunningOrders.Columns.Add("Count", 90);
            ListViewRunningOrders.Columns.Add("Description", 330);

            foreach (OrderDetail item in runningOrder)
            {
                ListViewItem li = new ListViewItem(item.Order_DetailID.ToString());
                li.SubItems.Add(item.Order_DetailID.ToString());
                li.SubItems.Add(item.Item_Quantity.ToString());
                li.SubItems.Add(item.MenuItem.Item_Name.ToString());
                li.Tag = item;
                ListViewRunningOrders.Items.Add(li);
            }
        }

        private void DisplayCompletedOrders(List<OrderDetail> completedOrder)
        {
            listViewCompletedOrders.Clear();
            listViewCompletedOrders.View = View.Details;
            listViewCompletedOrders.Columns.Add("Order ID", 110);
            listViewCompletedOrders.Columns.Add("Order number", 155); //should be table number
            listViewCompletedOrders.Columns.Add("Count", 90);
            listViewCompletedOrders.Columns.Add("Description", 330);

            foreach (OrderDetail item in completedOrder)
            {
                ListViewItem li = new ListViewItem(item.OrderDetailID.ToString());
                li.SubItems.Add(item.OrderDetailID.ToString());
                li.SubItems.Add(item.ItemQuantity.ToString());
                li.SubItems.Add(item.MenuItem.ItemName());
                li.Tag = item;
                listViewCompletedOrders.Items.Add(li);
            }
        }
        private void DisplayKitchenOrder(List<OrderDetail> orderDetail)
        {
            listViewOrderId.Clear();
            listViewOrderId.View = View.Details;
            listViewOrderId.Columns.Add("Order ID", 110);
            listViewOrderId.Columns.Add("Order number", 155); //should be table number
            listViewOrderId.Columns.Add("Count", 90);
            listViewOrderId.Columns.Add("Description", 330);
            listViewOrderId.Columns.Add("Time", 200);


            foreach (OrderDetail item in orderDetail)
            {

                ListViewItem li = new ListViewItem(item.Order_DetailID.ToString());
                li.SubItems.Add(item.Order_DetailID.ToString());
                li.SubItems.Add(item.Item_Quantity.ToString());
                li.SubItems.Add(item.MenuItem.Item_Name.ToString());
                li.SubItems.Add(item.Order_Time.ToString());
                li.Tag = item;
                listViewOrderId.Items.Add(li);
            }
        }

        private void ShowOrderDetailPanel()
        {
            KitchenPanel.Show();
            List<OrderDetail> orderDetails = GetOrderDetails();
            DisplayKitchenOrder(orderDetails);

            //List<OrderDetail> kitchenOrder = KitchenOrder();           
            //DisplayKitchenOrder(kitchenOrder);
        }

        private void PreparationBtn_Click(object sender, EventArgs e)
        {
            lblOrderStatusFirst.Text = "In preparation";
            KitchenBarTimer.Start();
        }

        private void PreaparedBtn_Click(object sender, EventArgs e)
        {
            lblOrderStatusFirst.Text = "Prepared";
        }

        //text alignment for column subitems
        private void lvorder(object sender, DrawListViewSubItemEventArgs e)
        {
            TextFormatFlags flags = TextFormatFlags.Left;

            if (e.ColumnIndex < 3)
            {
                flags = TextFormatFlags.HorizontalCenter;
            }
            e.DrawText(flags);
        }

        //text alignment for column header
        private void lvorder(object sender, DrawListViewColumnHeaderEventArgs e)
        {
            e.Graphics.FillRectangle(Brushes.Orange, e.Bounds);

            TextFormatFlags flags = TextFormatFlags.Left;
            if (e.ColumnIndex == 0)
            {
                flags = TextFormatFlags.HorizontalCenter;
            }
            e.DrawText(flags);

        }
        private void ViewSelectedOrderId(object sender, EventArgs e)
        {
            if (listViewOrderId.SelectedItems.Count > 0)
            {
                ListViewItem item = listViewOrderId.SelectedItems[0];
                lblSelectedFirst.Text = item.SubItems[0].Text;
            }
        }

        private void btnRunningOrders_Click(object sender, EventArgs e)
        {
            KitchenPanel.Hide();
            panelCompletedOrders.Hide();
            panelRunningOrders.Show();
            List<OrderDetail> runningOrder = RunningOrders();
            //  DisplayOrder(orderDetails);
            DisplayRunningOrders(runningOrder);

        }

        private void btnCompletedOrders_Click(object sender, EventArgs e)
        {
            KitchenPanel.Hide();
            panelRunningOrders.Hide();
            panelCompletedOrders.Show();
            List<OrderDetail> completedOrder = CompletedOrders();
            //  DisplayOrder(orderDetails);
            DisplayCompletedOrders(completedOrder);
        }

        private void btnOverviewFromRunning_Click(object sender, EventArgs e)
        {
            KitchenPanel.Show();
            panelRunningOrders.Hide();
            panelCompletedOrders.Hide();
        }

        private void btnOverviewFromCompleted_Click(object sender, EventArgs e)
        {
            KitchenPanel.Show();
            panelRunningOrders.Hide();
            panelCompletedOrders.Hide();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;
            if (username == "0004" && password == "0000")
            {
                KitchenLabel.Text = "Kitchen Orders";
                KitchenPanel.Show();
                panelRunningOrders.Hide();
                panelCompletedOrders.Hide();
                panelLogin.Hide();
            }
            else if (username == "0003" && password == "0000")
            {
                KitchenLabel.Text = "Bar Orders";
                KitchenPanel.Show();
                panelRunningOrders.Hide();
                panelCompletedOrders.Hide();
                panelLogin.Hide();
            }
            else
            {
                MessageBox.Show("something went wrong");
            }
        }
        private bool CheckOrderTime(OrderDetail orderdetail)
        {
            return orderdetail.Order_Status == OrderStatus.preparing;

        }
        private void ServedBtn_Click(object sender, EventArgs e)
        {
            lblOrderStatusFirst.Text = "Served";
            KitchenBarTimer.Stop();
        }

        private void KitchenBarTimer_Tick(object sender, EventArgs e)
        {
            labeltimer.Text = "hh:mm:ss";
        }

        private void panelLogin_Paint(object sender, PaintEventArgs e)
        {

        }

        //private void DisplayKitchenOrder(List<OrderDetail> kitchenOrder)
        //{
        //    listViewOrderId.Clear();
        //    listViewOrderId.View = View.Details;
        //    listViewOrderId.Columns.Add("Order ID", 110);
        //    listViewOrderId.Columns.Add("Order number", 155); //table number
        //    listViewOrderId.Columns.Add("Count", 90);
        //    listViewOrderId.Columns.Add("Description", 330);
        //    listViewOrderId.Columns.Add("Time", 200);


        //    foreach (OrderDetail item in kitchenOrder)
        //    {
        //        //string dateTimeToShow;
        //        //if (CheckOrderTime(item))
        //        //{
        //        //    TimeSpan dateTime = TimeSpan.FromMinutes(15);
        //        //   // var addSeconds = dateTime.Add(TimeSpan.FromSeconds(1));
        //        //    dateTimeToShow = dateTime.Minutes.ToString() + " min ago";
        //        //}
        //        ////else
        //        //{
        //        //    dateTimeToShow = item.DateTime.ToString("HH:mm");
        //        //}
        //        ListViewItem li = new ListViewItem(item.Order_DetailID.ToString());
        //        li.SubItems.Add(item.Order_DetailID.ToString());
        //        li.SubItems.Add(item.Item_Quantity.ToString());
        //        li.SubItems.Add(item.MenuItem.Item_Name.ToString());
        //        li.SubItems.Add(item.Order_Time.ToString());
        //        li.Tag = item;
        //        listViewOrderId.Items.Add(li);
        //    }
        //}
    }
}
